package br.edu.basquete;
import com.almasb.fxgl.physics.PhysicsComponent;
import com.almasb.fxgl.physics.box2d.dynamics.BodyType;
import com.almasb.fxgl.physics.box2d.dynamics.FixtureDef;

import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.Entity;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/** Agrupa visualmente o aro e a tabela da cesta. */
public class Cesta {

    private Entity aro;
    private Entity aroDireito;
    private Entity tabela;



    public void criar(double x, double y) {
        

        tabela = FXGL.entityBuilder()
                .at(x + 68, y - 55)
                .viewWithBBox(new Rectangle(10, 75, Color.WHITESMOKE))
                .buildAndAttach();

       aro = criarParteAro(x, y);

aroDireito = criarParteAro(x + 58, y);
        


    }
    
    private Entity criarParteAro(double x, double y) {
    PhysicsComponent fisica = new PhysicsComponent();

    fisica.setBodyType(BodyType.STATIC);

    FixtureDef fixture = new FixtureDef();

    fixture.setRestitution(0.7f);
    fixture.setFriction(0.3f);

    fisica.setFixtureDef(fixture);

    return FXGL.entityBuilder()
            .at(x, y)
            .viewWithBBox(new Rectangle(10, 7, Color.ORANGERED))
            .with(fisica)
            .buildAndAttach();
}
        public boolean verificarCesta(double centroX, double yAnterior, double yAtual) {

    double raioBola = 16;

    double limiteEsquerdo = aro.getX() + 10 + raioBola;
    double limiteDireito = aroDireito.getX() - raioBola;

    double linhaCesta = aro.getY() + 7 + raioBola;

    return yAnterior < linhaCesta
            && yAtual >= linhaCesta
            && centroX >= limiteEsquerdo
            && centroX <= limiteDireito;
}

   


    public Entity getAro() {
        return aro;
    }

    public Entity getTabela() {
        return tabela;
    }
}
