package br.edu.basquete;

/** Guarda a pontuação da partida e o melhor resultado da sessão. */
public class Pontuacao {

    private int pontos = 0;
    private int recorde = 0;

    public void adicionarPontos(int quantidade) {
        if (quantidade <= 0) {
            return;
        }

        pontos += quantidade;
        if (pontos > recorde) {
            recorde = pontos;
        }
    }

    public int getPontos() {
        return pontos;
    }

    public int getRecorde() {
        return recorde;
    }

    public void reiniciar() {
        pontos = 0;
    }

    // TODO: salvar/carregar o recorde em um arquivo.
}
