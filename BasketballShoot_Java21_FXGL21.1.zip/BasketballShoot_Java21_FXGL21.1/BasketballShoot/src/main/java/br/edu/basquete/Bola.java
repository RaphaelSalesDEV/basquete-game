package br.edu.basquete;
import com.almasb.fxgl.physics.PhysicsComponent;
import com.almasb.fxgl.physics.BoundingShape;
import com.almasb.fxgl.physics.HitBox;
import com.almasb.fxgl.physics.box2d.dynamics.BodyType;
import com.almasb.fxgl.physics.box2d.dynamics.FixtureDef;
import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.Entity;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Bola {

    private Entity entidade;

    public void criar(double x, double y) {
        PhysicsComponent fisica = new PhysicsComponent();

fisica.setBodyType(BodyType.DYNAMIC);
FixtureDef fixture = new FixtureDef();

fixture.setDensity(1f);
fixture.setRestitution(0.8f);
fixture.setFriction(0.2f);

fisica.setFixtureDef(fixture);
        fisica.setOnPhysicsInitialized(() -> {
    fisica.getBody().setGravityScale(0f);
    fisica.setLinearVelocity(0, 0);
});
        entidade = FXGL.entityBuilder()
        .at(x, y)
        .view(new Circle(16, 16, 16, Color.ORANGE))
        .bbox(new HitBox(BoundingShape.circle(16)))
        .with(fisica)
        .buildAndAttach();
    }
    public void arremessar(double velocidadeX, double velocidadeY) {

    PhysicsComponent fisica = entidade.getComponent(PhysicsComponent.class);

    fisica.getBody().setGravityScale(1f);

    fisica.setLinearVelocity(velocidadeX, velocidadeY);
}
    public Entity getEntidade() {
        return entidade;
    }
}
