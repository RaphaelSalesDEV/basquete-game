package br.edu.basquete;
import com.almasb.fxgl.physics.PhysicsComponent;
import com.almasb.fxgl.physics.box2d.dynamics.BodyType;
import com.almasb.fxgl.physics.box2d.dynamics.FixtureDef;

import com.almasb.fxgl.app.GameApplication;
import com.almasb.fxgl.app.GameSettings;
import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.input.UserAction;
import javafx.scene.shape.Circle;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.input.MouseButton;
import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/** Classe principal: cria a janela e conecta as outras classes. */
public class Jogo extends GameApplication {

    private Bola bola;
    private Cesta cesta;
    private Pontuacao pontuacao;
    private double inicioX;
private double inicioY;

private boolean arrastando = false;
private boolean jaArremessou = false;
private double yAnteriorBola;
private List<Circle> pontosTrajetoria = new ArrayList<>();

private static final double GRAVIDADE_JOGO = 600;
private static final double FORCA_HORIZONTAL = 6;
private static final double FORCA_VERTICAL = 6;
private static final double VELOCIDADE_MAXIMA = 800;

private boolean jaPontuou = false;

private Text placar;

    @Override
    protected void initSettings(GameSettings settings) {
        settings.setWidth(800);
        settings.setHeight(600);
        settings.setTitle("Basketball Shoot - Protótipo");
        settings.setVersion("0.1");
    }
        @Override
protected void initInput() {

    FXGL.getInput().addAction(new UserAction("Arremessar") {

        @Override
        protected void onActionBegin() {

            if (bola == null || jaArremessou) {
                return;
            }

            Point2D mouse = FXGL.getInput().getMousePositionWorld();
            Point2D centroBola = bola.getEntidade().getCenter();

            if (mouse.distance(centroBola) <= 20) {

                arrastando = true;

                inicioX = mouse.getX();
                inicioY = mouse.getY();
            }
        }

        @Override
        protected void onActionEnd() {

            if (!arrastando) {
                return;
            }

            arrastando = false;
            esconderTrajetoria();

            Point2D mouse = FXGL.getInput().getMousePositionWorld();

            Point2D velocidade = calcularVelocidade(mouse);

if (velocidade.magnitude() < 30) {
    return;
}

            bola.arremessar(velocidade.getX(), velocidade.getY());

            jaArremessou = true;
        }

    }, MouseButton.PRIMARY);
}

    @Override
    protected void initGame() {
        FXGL.getGameScene().setBackgroundColor(Color.web("#152238"));

        // Instâncias: cada objeto cuida de uma responsabilidade.
        pontuacao = new Pontuacao();
        bola = new Bola();
        cesta = new Cesta();

        PhysicsComponent fisicaChao = new PhysicsComponent();

fisicaChao.setBodyType(BodyType.STATIC);

FixtureDef fixtureChao = new FixtureDef();

fixtureChao.setRestitution(0.2f);
fixtureChao.setFriction(0.7f);

fisicaChao.setFixtureDef(fixtureChao);
        // Chão visual. A colisão física será feita depois.
        FXGL.entityBuilder()
        .at(0, 550)
        .viewWithBBox(new Rectangle(800, 50, Color.DARKSLATEGRAY))
        .with(fisicaChao)
        .buildAndAttach();

        bola.criar(130, 430);
        yAnteriorBola = bola.getEntidade().getCenter().getY();
        cesta.criar(610, 340);

        // TODO: ativar a física da bola e das partes da cesta.
        // TODO: adicionar o arremesso controlado pelo mouse.
        // TODO: detectar quando a bola atravessa a cesta.
    }
    @Override
protected void initPhysics() {
    FXGL.getPhysicsWorld().setGravity(0, GRAVIDADE_JOGO);
}
    @Override
    protected void initUI() {
        placar = new Text("Pontos: " + pontuacao.getPontos()
                + "     Recorde: " + pontuacao.getRecorde());
        placar.setFill(Color.WHITE);
        placar.setFont(Font.font(20));
        placar.setTranslateX(20);
        placar.setTranslateY(35);
        FXGL.getGameScene().addUINode(placar);
        for (int i = 0; i < 20; i++) {
    //Cria trajetoria
    Circle ponto = new Circle(3, Color.WHITE);

    ponto.setVisible(false);
    ponto.setMouseTransparent(true);

    FXGL.getGameScene().addUINode(ponto);

    pontosTrajetoria.add(ponto);
    
}

        // TODO: atualizar o texto quando a pontuação mudar.
    }
    private Point2D calcularVelocidade(Point2D mouse) {

    double vx = (inicioX - mouse.getX()) * FORCA_HORIZONTAL;
    double vy = (inicioY - mouse.getY()) * FORCA_VERTICAL;

    double velocidadeTotal = Math.hypot(vx, vy);

    if (velocidadeTotal > VELOCIDADE_MAXIMA) {

        vx = vx * VELOCIDADE_MAXIMA / velocidadeTotal;
        vy = vy * VELOCIDADE_MAXIMA / velocidadeTotal;
    }

    return new Point2D(vx, vy);
}
    private void mostrarTrajetoria() {

    Point2D mouse = FXGL.getInput().getMousePositionWorld();

    // Calcula a velocidade prevista do arremesso
    Point2D velocidade = calcularVelocidade(mouse);
    



System.out.println("Velocidade horizontal atual: " + velocidade.getX());
System.out.println("Velocidade vertical atual: " + velocidade.getY());

double vx = velocidade.getX();
double vy = velocidade.getY();

    // Se o jogador quase nao arrastou, nao mostra a trajetoria
    if (velocidade.magnitude() < 30) {
        esconderTrajetoria();
        return;
    }


    // Posicao inicial da bola
    double x0 = bola.getEntidade().getCenter().getX();
    double y0 = bola.getEntidade().getCenter().getY();

    // Converte a gravidade para pixels por segundo ao quadrado
    double gravidade = FXGL.getPhysicsWorld().toPixels(GRAVIDADE_JOGO);

    for (int i = 0; i < pontosTrajetoria.size(); i++) {

        double tempo = (i + 1) * 0.10;

        double x = x0 + vx * tempo;

        double y = y0 + vy * tempo
                + 0.5 * gravidade * tempo * tempo;

        Circle ponto = pontosTrajetoria.get(i);

        ponto.setTranslateX(x);
        ponto.setTranslateY(y);

        // Mostra somente os pontos dentro da area do jogo
        ponto.setVisible(
                x >= 0 && x <= 800 &&
                y >= 0 && y <= 550
        );
    }
}
private void esconderTrajetoria() {

    for (Circle ponto : pontosTrajetoria) {

        ponto.setVisible(false);

    }
}
    @Override
protected void onUpdate(double tpf) {

    if (bola == null || cesta == null || pontuacao == null) {
        return;
    }
    if (arrastando && !jaArremessou) {

    mostrarTrajetoria();

}

    double centroX = bola.getEntidade().getCenter().getX();
    double centroY = bola.getEntidade().getCenter().getY();

    if (jaArremessou && !jaPontuou &&
            cesta.verificarCesta(centroX, yAnteriorBola, centroY)) {

        pontuacao.adicionarPontos(1);

        jaPontuou = true;

        placar.setText("Pontos: " + pontuacao.getPontos()
                + "     Recorde: " + pontuacao.getRecorde());
    }

    yAnteriorBola = centroY;
}

    public static void main(String[] args) {
        launch(args);
    }
}
