# Basketball Shoot — projeto-base (POO + Java + FXGL)

Este é um **protótipo inicial**, não um jogo finalizado. A ideia é estudar POO implementando as funcionalidades em etapas.

## Versões usadas

- **Java JDK 21**: versão principal do Java, incluindo atualizações 21.0.x (por exemplo, 21.0.1).
- **FXGL 21.1**: versão da biblioteca para jogos (não é versão do Java).
- **JavaFX 21.0.2**: dependência gráfica baixada pelo Maven.

O Java não possui uma versão pública intitulada `21.1` neste padrão. No `pom.xml`, `maven.compiler.release=21` indica o Java 21 e `fxgl.version=21.1` indica o FXGL 21.1.

## Requisitos

- **JDK 21** (confira com `java -version`).
- **Maven** instalado e disponível no terminal (confira com `mvn -version`).
- VS Code com o **Extension Pack for Java**, ou uma IDE compatível com Maven.
- Internet no primeiro uso, para o Maven baixar as dependências do `pom.xml`.

> A base foi configurada para FXGL **21.1**, compatível com Java 21. Se sua turma usa JDK 17, será necessário ajustar a versão do FXGL e do compilador, não apenas mudar o Java instalado.

## Como abrir no VS Code

1. Descompacte o ZIP.
2. No VS Code, escolha **Arquivo > Abrir Pasta** e selecione **BasketballShoot** (a pasta que contém `pom.xml`).
3. Aguarde a importação do projeto Maven.
4. Abra um terminal na pasta e execute:

   ```bash
   mvn clean javafx:run
   ```

A primeira inicialização pode demorar por causa do download das bibliotecas.

## O que já existe

- `Jogo.java`: inicia a janela FXGL, desenha o chão e chama as outras classes.
- `Bola.java`: cria uma bola **visual**, ainda sem gravidade.
- `Cesta.java`: cria aro e tabela **visuais**, ainda sem colisões.
- `Pontuacao.java`: armazena pontos e recorde **em memória**, mas ainda não atualiza o placar na tela nem salva em disco.
- `pom.xml`: configura as dependências e o comando `mvn javafx:run`.

O resultado inicial esperado é uma janela 800×600 com fundo azul-escuro, chão, bola laranja, aro, tabela e um placar zerado. **A bola ainda não se move, não é arremessada e não faz cesta.**

## Próximos passos (na ordem sugerida)

1. Adicionar física e colisão à `Bola` usando `PhysicsComponent`.
2. Configurar colisões do chão, aro e tabela.
3. Capturar arrastar/soltar do mouse e aplicar velocidade à bola.
4. Detectar uma cesta válida e atualizar `Pontuacao` e o texto na interface.
5. Persistir o recorde e criar tela/menu de reinício.

## Árvore do projeto

```text
BasketballShoot/
├── pom.xml
├── README.md
├── .gitignore
└── src/
    └── main/
        ├── java/
        │   └── br/edu/basquete/
        │       ├── Jogo.java
        │       ├── Bola.java
        │       ├── Cesta.java
        │       └── Pontuacao.java
        └── resources/
            └── assets/
                ├── textures/       (imagens futuras)
                └── sounds/         (sons futuros)
```

As pastas `textures` e `sounds` têm somente um arquivo `.gitkeep` como marcador. Nenhuma imagem externa é necessária por enquanto: os desenhos usam formas simples do JavaFX.

## Observação

O projeto usa a forma *não modular* (sem `module-info.java`) para manter a introdução ao Java/FXGL mais simples.
